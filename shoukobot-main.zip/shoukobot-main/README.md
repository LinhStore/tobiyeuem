# SHOUKO COLLECTIVE | NON-INTELLIGENT UNITS | 2024

## Getting Started

To install the required dependencies, run the following command:

---> npm install discord.js

## Troubleshooting

If you experience issues with imports, replace "import" statements with "const" declarations.

## Support

For further assistance, join our support community on Discord: https://discord.gg/shoukohub

---

Thank you for choosing Shouko Collective!
